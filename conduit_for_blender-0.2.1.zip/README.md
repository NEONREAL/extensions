# Advanced Blender extension preset:

- comes with github action for building and releasing zips
- automatically fetches relevant info from the manifest into the ```__init__.py``` file
- comes with sample operator and panel for learning the basics
- comes with an organized, ready to use file structure

any feedback always welcome!
