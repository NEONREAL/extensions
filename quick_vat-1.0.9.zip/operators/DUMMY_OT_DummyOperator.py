import bpy  # type: ignore
from ..constants import get_operator
from .vat_logic import calculate_dimensions

class DUMMY_OT_DummyOperator(bpy.types.Operator):
    bl_idname = get_operator("dummy")
    bl_label = "Generate Texture dimensions"




    def execute(self, context):
        verts = len(context.active_object.data.vertices)
        frames = 1000
        calculate_dimensions(verts = verts, frames=frames)

        print("----------------------")
        return {"FINISHED"}

