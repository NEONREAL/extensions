import bpy
import bpy.utils.previews
import os

preview_collections = {}

def load_icons():
    icons_dir = os.path.join(os.path.dirname(__file__))
    pcoll = bpy.utils.previews.new()
    pcoll.load("prism_logo", os.path.join(icons_dir, "prism_logo.png"), 'IMAGE')
    pcoll.load("unity_logo", os.path.join(icons_dir, "unity_logo.png"), 'IMAGE')

    preview_collections["main"] = pcoll

def unload_icons():
    for pcoll in preview_collections.values():
        bpy.utils.previews.remove(pcoll)
    preview_collections.clear()