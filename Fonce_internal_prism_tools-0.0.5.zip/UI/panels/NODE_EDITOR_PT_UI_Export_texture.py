import bpy
from ...msc.util import getImgPath
from ..Icons.icons import preview_collections
from ...constants import get_addon_preferences


class PT_Export_Texture(bpy.types.Panel):
    bl_label = "Prism Texture"
    bl_idname = "PT_Export_Texture"
    bl_space_type = "NODE_EDITOR"
    bl_region_type = "UI"
    bl_category = "Prism"

    def draw(self, context):
        draw_essentials(self)
        create(self, context)
        load(self)
        ingest(self)
        row = self.layout.row()
        row.enabled = False
        row.label(text="(This addon is not affiliated with Prism)")

def draw_essentials(self):
    layout = self.layout
    Box = layout.box()
    
    row = Box.row()
    row.split(factor=0.6)
    row.label(text="Department:")
    row.prop(bpy.context.scene.prism_properties, "Departments", text = "")

    row = Box.row()
    row.split(factor=0.6)
    row.label(text="Task:")
    row.prop(bpy.context.scene.prism_properties, "Tasks", text = "")

def ingest(self):
     layout = self.layout
     row = layout.row()
     row.scale_y = 2
     row.operator("prismtools.ingestimg", text = "Ingest selected Textures", icon = 'LIBRARY_DATA_DIRECT')

def create(self, context):
        create_toggle = bpy.context.scene.prism_properties
        layout = self.layout
        Box = layout.box()
        Row = Box.row()
        Row.label(text="Create new Texture")
        #Row.prop(create_toggle, "Create", toggle = True, text = "", icon = "HIDE_OFF" if create_toggle["Create"] else "HIDE_ON")
        
        if True: 
            row = Box.row()
            row.scale_y = 1.5
            preferences = get_addon_preferences(context)
            row.prop(preferences, "Resolution", text="Default Import Option", expand=True)



            row = Box.row()
            row.scale_y = 2
            pcoll = preview_collections.get("main")
            if pcoll:
                icon_id = pcoll["prism_logo"].icon_id
                row.operator("prismtools.addimg", icon_value=icon_id, text = "Create Texture")
            else:
                layout.label(text="Icon not loaded")
        #row = Box.row()
        #row.operator("prismtools.debug", text = "debug")

def load(self):

    layout = self.layout
    scene = bpy.context.scene
    load_toggle = scene.prism_properties

    box = layout.box()
    Row = box.row()
    Row.label(text="Import from Prism")
    #Row.prop(load_toggle, "Import", toggle = True, text = "", icon = "HIDE_OFF" if load_toggle["Import"] else "HIDE_ON")


    if True:
        row =box.row()
        row.template_list("LIST_file_list", "", scene, "image_list_data", scene, "image_list_index")
        
        row = box.row(align=True)
        row.scale_y = 2
        row = row.split(factor=0.85, align = True)
        row.operator("prismtools.importimg", text="Import to Blender", icon = "IMPORT") 
        row.prop(bpy.context.scene.prism_properties, "Connect", text="", icon = "DRIVER")
        box.label(text=getImgPath())


        



