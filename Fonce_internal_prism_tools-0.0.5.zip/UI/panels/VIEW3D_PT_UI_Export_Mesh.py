import bpy
from ...constants import get_addon_preferences, AddonProperties
from ..Icons.icons import preview_collections

class VIEW3D_PT_UI_Sample(bpy.types.Panel):
    bl_label = "Prism Tools"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = AddonProperties.panel_category


    def draw(self, context):
        preferences = get_addon_preferences(context)
        layout = self.layout
        box = layout.box()
        box.label(text="FBX Exporter", icon='EXPORT')

        row = box.row()
        row.prop(preferences, "ExportType", text="Export Type", expand=True)


        row = box.row()
        row.scale_y = 1.5
        row = row.split(factor=0.8, align=True)
        
        pcoll = preview_collections.get("main")
        if pcoll:
            icon_id = pcoll["unity_logo"].icon_id
        row.operator("object.export_to_unity", text="Export Selected to Unity", icon_value=icon_id)
        row.prop(preferences, "Export_Textures", text="", expand = True, icon='TEXTURE')
    
        row = box.row()
        row.prop(preferences, "Export_Materials", text="Include Materials", icon='MATERIAL')
    
        row = box.column()
        row.enabled = False
        row.label(text = preferences.UnityPath)




