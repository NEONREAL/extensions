import bpy
import tomllib
import os

#Operators
from .operators.OBJECT_OT_Export_Mesh       import OBJECT_OT_export_fbx_to_unity 
from .operators.IMAGE_OT_Import_Image_From_Prism import IMAGE_OT_import_image_from_prism
from .operators.IMAGE_OT_Image_To_Prism import IMAGE_OT_image_to_prism

#panels
from .UI.panels.VIEW3D_PT_UI_Export_Mesh        import VIEW3D_PT_UI_Sample
from .UI.panels.NODE_EDITOR_PT_UI_Export_texture import PT_Export_Texture

#msc
from .msc.PT_Preferences                    import PT_Preferences
from .msc.PG_PrismPropertyGroup             import PG_PrismPropertyGroup
from .msc.TX_List                           import LIST_file_list, LIST_image_item, LIST_refresh_list

from .UI.Icons.icons import load_icons, unload_icons
#reading values such as name, version and more from toml so there is no need to change information in two places
def load_manifest_info():
    toml_path = os.path.join(os.path.dirname(__file__), "blender_manifest.toml")
    with open(toml_path, "rb") as f:
        manifest = tomllib.load(f)

    #reading addon name
    extension_name = manifest["name"]

    #reading addon version
    version_str = manifest["version"]
    version_tuple = tuple(int(x) for x in version_str.split("."))

    #reading Blender version
    blender_version_str = manifest["blender_version_min"]
    blender_version_tuple = tuple(int(x) for x in blender_version_str.split("."))

    bl_info = {
    "name": extension_name,
    "version": version_tuple, 
    "blender": blender_version_tuple,
    }

    return bl_info

manifest = load_manifest_info()
bl_info = {
    "name": manifest["name"],
    "description": "Internal Tools to help smoothen the workflow between Prism, Blender and Unity",
    "author": "Fynn Luft", #(excellent movie)
    "version": manifest["version"], 
    "blender": manifest["blender"],
    "location": "Npanel",
    "support": "NEONREAL",
    "category": "UI",
}



classes = [
    #Lists
    LIST_file_list,
    LIST_image_item,
    LIST_refresh_list,     
    #preferences
    PT_Preferences,
    PG_PrismPropertyGroup,     
    #operators:
    OBJECT_OT_export_fbx_to_unity,  
    IMAGE_OT_import_image_from_prism,
    IMAGE_OT_image_to_prism,    
    #panels:
    VIEW3D_PT_UI_Sample,
    PT_Export_Texture

    ]



def register():
    for i in classes:
        bpy.utils.register_class(i)

    bpy.types.Scene.prism_properties = bpy.props.PointerProperty(type=PG_PrismPropertyGroup)
    bpy.types.Scene.image_list_data = bpy.props.CollectionProperty(type=PG_PrismPropertyGroup)
    bpy.types.Scene.image_list_index = bpy.props.IntProperty()

    load_icons ()

def unregister():
    for i  in reversed(classes):
        bpy.utils.unregister_class(i)
    unload_icons()

if __name__ == "__main__":
    register() 