import bpy
from ..constants import AddonProperties

class PT_Preferences(bpy.types.AddonPreferences):
    bl_idname = AddonProperties.module_name
    Resolutions = [
        ('512', "512", ""),
        ('1024', "1k", ""),
        ('2048', "2k", ""),
        ('4096', "4k", ""),
    ]

    ImageSrc: bpy.props.StringProperty(default = "C:\\") #type: ignore
    UnityPath: bpy.props.StringProperty(
        name="Path to the Unity Project",
        description="Example: C:\\Users\\User\\Documents\\UnityProjects\\FONCE\\Assets\\!Neonreal",
        default="C:\\Users\\Fxnarji\\Documents\\GitHub\\FONCE\\Assets\\!Neonreal",
        subtype='FILE_PATH',
    )#type: ignore

    Export_Textures: bpy.props.BoolProperty(
        name="Export Textures",
        description="Export the textures to the Unity Project",
        default=True
    )#type: ignore

    Export_Materials: bpy.props.BoolProperty(
        name = "Clean Materials",
        description="Remove all materials during export process",
        default=True
    )#type: ignore

    ExportType: bpy.props.EnumProperty(
        name="Export Type",
        description="Choose the type of export",
        items=[
            ('SINGLE', "Single", "Export all Selected objects in one file"),
            ('INDIVIDUAL', "Individual", "Exports each selected object individually"),
        ],
        default='SINGLE'
    )#type: ignore

    Resolution: bpy.props.EnumProperty(
        name="Resolutions",
        description="Pick a resolution",
        items=Resolutions,
        default="1024"
    )#type: ignore

    def draw(self, context):
        layout = self.layout
        layout.label(text="Put your Unity Project Path here:")
        layout.prop(self, "UnityPath")
