from ProjectScripts.SceneBrowser import SceneBrowser
import PrismInit as prism
import os
import bpy


def getCurrentEntity():
    sb = SceneBrowser(prism.pcore)
    return sb.getCurrentEntity()

def getAssetPath():
    asset_path = prism.pcore.getAssetPath()
    path = os.path.normpath(asset_path)
    return path 

def getDepartments(self, context):
    try:
        p = prism.pcore
        FileName = p.getCurrentFileName()
        Data = p.getScenefileData(FileName)
        Filepath = Data["filename"]

        for _ in range(3):
            Filepath = os.path.dirname(Filepath)

        departments = os.listdir(Filepath)

        # Convert to enum items: (identifier, name, description)
        return [(d, d, "") for d in departments if os.path.isdir(os.path.join(Filepath, d))]
    except Exception as e:
        print(f"Failed to get departments: {e}")
        return []

def getTasks(self, context):
    p = prism.pcore
    FileName = p.getCurrentFileName()
    Data = p.getScenefileData(FileName)
    Filepath = Data["filename"]

    for _ in range(3):
        Filepath = os.path.dirname(Filepath)
    Filepath = os.path.join(Filepath, bpy.context.scene.prism_properties.Departments)
    tasks = os.listdir(Filepath)
    return [(t, t, "") for t in tasks if os.path.isdir(os.path.join(Filepath, t))]

def popup(msg):
    prism.pcore.popup(msg, severity = "info")

def refresh_image_list(self, context):
    scene = context.scene
    scene.image_list_data.clear()


    folder_path = getImgPath()

    if not os.path.exists(folder_path):
        print(f"Folder not found: {folder_path}")
        return

    for filename in os.listdir(folder_path):
        lower_name = filename.lower()
        if lower_name.endswith((".png", ".jpg", ".jpeg", ".bmp", ".tga", ".exr")) and not lower_name.endswith("preview.jpg"):
            item = scene.image_list_data.add()
            item.name = filename

def getImgPath():
    p = prism.pcore
    FileName = p.getCurrentFileName()
    Data = p.getScenefileData(FileName)
    Filepath = Data["filename"]
    for _ in range(3):
        Filepath = os.path.dirname(Filepath)

    img_path = os.path.join(Filepath, bpy.context.scene.prism_properties.Departments, bpy.context.scene.prism_properties.Tasks)
    img_path = os.path.normpath(img_path)
    return img_path #"Y:\\AudioVis\\03_Production\\Assets\\03_Assets\\Temp\\Scenefiles\\surf\\Diffuse"

def debug():
    p = prism.pcore
    out = p.getCurrentFileName()
    #out = p.getLocalPath()
    out = p.getScenefileData(out)
    out = str(out)
    os.system(f'echo {out.strip()}| clip')
    return out 



{'project_path': 'Y:\\AudioVis', 
 'asset_path': '03_Assets\\Temp', 
 'department': 'mod', 
 'task': 'Modeling', 
 'asset': 'Temp', 
 'version': 'v0001', 
 'type': 'asset', 
 'locations': {'global': 'Y:\\AudioVis\\03_Production\\Assets\\03_Assets\\Temp\\Scenefiles\\mod\\Modeling\\Temp_Modeling_v0001.blend'}, 
 'user': 'fxn', 
 'comment': '', 
 'username': 'Fxnarji', 
 'filename': 'Y:\\AudioVis\\03_Production\\Assets\\03_Assets\\Temp\\Scenefiles\\mod\\Modeling\\Temp_Modeling_v0001.blend', 
 'extension': '.blend'}
