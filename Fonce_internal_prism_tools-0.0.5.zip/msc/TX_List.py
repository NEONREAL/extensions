import bpy
from ..msc.util import refresh_image_list



# Item in the list
class LIST_image_item(bpy.types.PropertyGroup):
    name: bpy.props.StringProperty(name="Name") #type: ignore
    resolution: bpy.props.IntProperty(name="Resolution")#type:ignore

# UIList definition
class LIST_file_list(bpy.types.UIList):
    def draw_item(self, context, layout, data, item, icon, active_data, active_propname, index):
        if self.layout_type in {'DEFAULT', 'COMPACT'}:
            layout.label(text=item.name, icon='IMAGE_DATA')
        elif self.layout_type == 'GRID':
            layout.alignment = 'CENTER'
            layout.label(text="")

class LIST_refresh_list(bpy.types.Operator):
    bl_idname = "prismtools.load_imgs"
    bl_label = "Load Image Files"
    def execute(self, context):
        refresh_image_list(context)
        return {"FINISHED"}


