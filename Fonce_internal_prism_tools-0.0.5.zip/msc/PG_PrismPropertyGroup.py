import bpy
from .util import getDepartments, getTasks, refresh_image_list

class PG_PrismPropertyGroup(bpy.types.PropertyGroup):
    Departments: bpy.props.EnumProperty(
        name = "departments",
        items = getDepartments, 
        update=refresh_image_list
        )#type: ignore
    
    Tasks: bpy.props.EnumProperty(
        name = "tasks",
        items = getTasks, 
        update=refresh_image_list
        )#type: ignore
    
    Connect: bpy.props.BoolProperty(
        name = "connect", 
        default = False
        )#type: ignore
    #UI

    Create: bpy.props.BoolProperty(
        name = "create_toggle", 
        default = False
        )#type: ignore
    
    Import: bpy.props.BoolProperty(
        name = "import_toggle", 
        default = False
        )#type: ignore


