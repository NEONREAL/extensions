import bpy
#i like to put values i need in multiple places here so i can change them in one place

class AddonProperties:
    module_name = __package__
    panel_category = "Prism Tools"

def get_addon_preferences(context):
    key = __package__
    if key not in context.preferences.addons:
        print(f"[AddonPrefs] Addon key '{key}' not found in preferences.addons")
        return None
    return context.preferences.addons[key].preferences
