import bpy
import os
from ..msc.util import getImgPath, popup
import ast
from mathutils import Vector

def importImage(index = None):

    scene = bpy.context.scene
    try:
        image = scene.image_list_data[index or scene.image_list_index]
    except:
        image = scene.image_list_data[index or len(scene.image_list_data)-1]
    ImageFolderPath = getImgPath()
    ImagePath = os.path.join(ImageFolderPath, image.name)
    image = image.name

    if image in bpy.data.images:
        return image
    
    bpy.ops.image.open(
        filepath = ImagePath,
        relative_path = True
        )
    return image

def arrangeNode(child, parent, offset = Vector((0,0))):
    child.location = parent.location - Vector((child.width+15, 0))
    child.location = child.location + offset

def connectToShader(mat, current_node):

    #Finding / creating Principled Shader
    data = ast.literal_eval(current_node.name)
    type = data.get("task")

    shader = find_task_node('SHADER')

    if shader is None:
        for node in mat.node_tree.nodes:
            if node.type == 'BSDF_PRINCIPLED':
                shader = node

    if shader is None:
        shader = createPrismNode(mat,'ShaderNodeBsdfPrincipled', "SHADER", None)
        
    #Finding / Creating Output
    material_output = None
    for node in mat.node_tree.nodes:
        if node.type == 'OUTPUT_MATERIAL':
            material_output = node
    
    if material_output is None:
        material_output = mat.node_tree.nodes.new(type = 'ShaderNodeOutputMaterial')
    
    #Linking Shader + Output Together
    links = mat.node_tree.links
    links.new(shader.outputs['BSDF'], material_output.inputs['Surface'])
    arrangeNode(shader, material_output)

    # Arranging and Connecting Nodes
    offset_y = 275
    offset_x = -50
    if type.lower() == "diffuse" or type.lower == "albedo":
        links.new(current_node.outputs['Color'], shader.inputs['Base Color'])
        arrangeNode(current_node, shader, Vector((offset_x,1*offset_y)))
    
    elif type.lower() == "metallic":
        links.new(current_node.outputs['Color'], shader.inputs['Metallic'])
        arrangeNode(current_node, shader, Vector((offset_x,0*offset_y)))
        current_node.image.colorspace_settings.name = 'Non-Color' 
    
    elif type.lower() == "roughness":
        links.new(current_node.outputs['Color'], shader.inputs['Roughness'])
        arrangeNode(current_node, shader, Vector((offset_x,-1 * offset_y)))
        current_node.image.colorspace_settings.name = 'Non-Color' 
    
    elif type.lower() == "normal":
        normal_conversion = mat.node_tree.nodes.new(type='ShaderNodeNormalMap')
        arrangeNode(normal_conversion, shader, Vector((offset_x, -2 * offset_y)))
        arrangeNode(current_node, normal_conversion)
        links.new(current_node.outputs['Color'], normal_conversion.inputs['Color'])
        links.new(normal_conversion.outputs['Normal'], shader.inputs['Normal'])
        current_node.image.colorspace_settings.name = 'Non-Color' 
    
    elif type.lower() == "emission":
        links.new(current_node.outputs['Color'], shader.inputs[27])
        arrangeNode(current_node, shader, Vector((offset_x,-3 * offset_y)))
    
    else:
        links.new(current_node.outputs['Color'], shader.inputs[27])
        links.new(current_node.outputs['Color'], shader.inputs[0])
        arrangeNode(current_node, shader, Vector((-300,0)))
    
def createPrismNode(mat, node_type, task, version):

    #Name
    info_dict = {
        "prism": True,
        "task": task,
        "version": version
    }
    name = info_dict

    #Label
    label = "PRISM " + task
    if version is not None:
        label = label + "V" + version


    nodes = mat.node_tree.nodes
    
    new_node = nodes.new(type=node_type)
    new_node.label = label
    new_node.name = str(name)
    new_node.use_custom_color = True

    if task == "SHADER":
        new_node.color = (0.347237, 0.5, 0.170596)
    else:
        new_node.color = (0.258, 0.09, 0.3)

    
        

    return new_node

def add_image_to_shader(image):
    if image is None:
        return
    
    obj = bpy.context.active_object
    if not obj or not obj.data.materials:
        print("No active object with materials.")
        return

    # Get or create active material
    mat = obj.active_material
    if not mat:
        mat = bpy.data.materials.new(name="Material")
        obj.data.materials.append(mat)


    mat.use_nodes = True


    # Create image texture node
    image = bpy.data.images[image]
    version = image.name[-8:]


    tex_node = find_task_node()
    created = False
    if tex_node is None:
        created = True
        tex_node = createPrismNode(mat, 'ShaderNodeTexImage',bpy.context.scene.prism_properties.Tasks,version)
    tex_node.label = "PRISM " + bpy.context.scene.prism_properties.Tasks + " V" + version
    tex_node.image = image

    if bpy.context.scene.prism_properties.Connect and created is True:
        connectToShader(mat = mat, current_node = tex_node)

def find_task_node(task = None):
    if task is None:
        task = bpy.context.scene.prism_properties.Tasks

    nodes = findPrismNodes()
    if not nodes:
        return None
    found_node = None
    node_counter = 0
    for node in nodes:
        try:
            data = ast.literal_eval(node.name)
            if data.get("task") == task:
                found_node = node
                node_counter = node_counter + 1
        except (ValueError, SyntaxError):
            continue
    if node_counter > 1:
        popup(f"Found more than one {task} nodes!")
    return found_node

def findPrismNodes():
    obj = bpy.context.object
    if not obj:
        return []

    mat = obj.active_material
    if not mat or not mat.use_nodes:
        return []

    prism_nodes = []
    for node in mat.node_tree.nodes:
        try:
            data = ast.literal_eval(node.name)
            if isinstance(data, dict) and data.get("prism") is True:
                prism_nodes.append(node)
        except (ValueError, SyntaxError):
            continue

    return prism_nodes

class IMAGE_OT_import_image_from_prism(bpy.types.Operator):
    bl_idname = "prismtools.importimg"
    bl_label = "add images"
    bl_options = {'REGISTER','UNDO'}

    
    def execute(self,context):

        image = importImage()
        if image is not None:
            add_image_to_shader(image)
            bpy.ops.file.make_paths_relative()
        return {'FINISHED'}
