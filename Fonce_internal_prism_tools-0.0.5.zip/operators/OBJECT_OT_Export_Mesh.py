import bpy
import os
from ..msc.util import popup 
import re
import PrismInit as prism
from ..constants import get_addon_preferences
import shutil


# Define the operator to snap FK bones to IK bones
class OBJECT_OT_export_fbx_to_unity(bpy.types.Operator):
    bl_idname = "sample.operator"
    bl_description = "Exports selected objects to Unity as FBX files"
    bl_label = "Exports selected objects to Unity as FBX files"
    bl_options = {'REGISTER', 'UNDO'}

    #optional but handy: this will make sure the operator can only run when there is an active object


    def export_textures(self, context):
        p = prism.pcore
        FileName = p.getCurrentFileName()
        Data = p.getScenefileData(FileName)
        preferences = get_addon_preferences(context)
        root = preferences.UnityPath        
        asset_path = Data["asset_path"]
        root = preferences.UnityPath

        filepath = bpy.data.filepath
        path = os.path.dirname(os.path.dirname(os.path.dirname(filepath)))
        if path + "\\tex":
            path += "\\tex"
        else:
            print("womp womp")
            return
        

        version_pattern = re.compile(r"_v(\d+)\.(png|jpg)$", re.IGNORECASE)

        for folder in os.listdir(path):
            folder_path = os.path.join(path, folder)
            if not os.path.isdir(folder_path):
                continue

            highest_version = -1
            highest_file = None

            for image in os.listdir(folder_path):
                match = version_pattern.search(image)
                if match:
                    version_num = int(match.group(1))
                    print(version_num)
                    if version_num > highest_version:
                        highest_version = version_num
                        highest_file = image

            if highest_file:
                src_file = os.path.join(folder_path, highest_file)
                dst_folder = os.path.join(root,asset_path)
                print(dst_folder)
                os.makedirs(dst_folder, exist_ok=True)
                dst_file = os.path.join(dst_folder, highest_file)
                shutil.copy2(src_file, dst_file)
                print(f"Copied {src_file} to {dst_file}")

    def get_export_path(self, context, suffix = ""):
        p = prism.pcore
        FileName = p.getCurrentFileName()
        Data = p.getScenefileData(FileName)
        root = get_addon_preferences(context).UnityPath     
        task = Data["task"]
        asset_path = Data["asset_path"]
        asset_name = Data["asset"]
        seperator = "_"
        if task == "Modeling":
            task = ""
            seperator = ""
        name = asset_name + seperator + task
  
        path = os.path.join(root, asset_path, task, name)
  
        
        if not os.path.exists(os.path.dirname(path)):
            os.makedirs(os.path.dirname(path))
            popup(f"Created directory: " + asset_path + task)


        self.report({'INFO'}, f"Exporting to: {path}")
        return path

    def export_individual(self, context):
        Export_materials = get_addon_preferences(context).Export_Materials

        for obj in bpy.context.selected_objects:
            if obj.type == 'MESH':
                # Store original materials if needed
                original_materials = []
                if not Export_materials:
                    original_materials = [slot.material for slot in obj.material_slots]
                    obj.data.materials.clear()

                # Deselect all objects
                bpy.ops.object.select_all(action='DESELECT')

                # Select only this object
                obj.select_set(True)
                bpy.context.view_layer.objects.active = obj

                # Build the path
                export_path = self.get_export_path(context) + f"_{obj.name}.fbx"
                os.makedirs(os.path.dirname(export_path), exist_ok=True)

                # Export the single object
                bpy.ops.export_scene.fbx(
                    filepath=export_path,
                    use_selection=True,
                    apply_scale_options='FBX_SCALE_ALL',
                    object_types={'MESH'},
                    bake_space_transform=True,
                )
                self.report({'INFO'}, f"Exported {obj.name} to {export_path}")

                # Restore materials if they were cleared
                if not Export_materials:
                    obj.data.materials.clear()
                    for mat in original_materials:
                        obj.data.materials.append(mat)

    def export_single(self, context):
        original_materials = {}
        filepath = self.get_export_path(context) + ".fbx"
        mesh_objects = [obj for obj in bpy.context.selected_objects if obj.type == 'MESH']

        Export_materials = get_addon_preferences(context).Export_Materials
        # Store and remove materials
        if not Export_materials:
            for obj in mesh_objects:
                original_materials[obj.name] = [slot.material for slot in obj.material_slots]
                obj.data.materials.clear()

        # Export all selected objects
        bpy.ops.object.select_all(action='DESELECT')
        for obj in mesh_objects:
            obj.select_set(True)
        bpy.context.view_layer.objects.active = mesh_objects[0]  # set one as active

        bpy.ops.export_scene.fbx(
            filepath=filepath,
            use_selection=True,
            apply_scale_options='FBX_SCALE_ALL',
            object_types={'MESH'},
            bake_space_transform=True,
        )

        print(f"Exported FBX without materials to: {filepath}")

        if not Export_materials:
            for obj in mesh_objects:
                obj.data.materials.clear()
                for mat in original_materials[obj.name]:
                    obj.data.materials.append(mat)

        print("Materials restored for all exported objects.")


    @classmethod
    def poll(cls, context):
        return context.active_object is not None
    
    bl_idname = "object.export_to_unity"
    bl_label = "Export FBX to Unity"


    def execute(self, context):
        
        if get_addon_preferences(context).ExportType == 'INDIVIDUAL':
            self.export_individual(context)
        else:
            self.export_single(context)


        if get_addon_preferences(context).Export_Textures:
            self.export_textures(context)
        return {'FINISHED'}


