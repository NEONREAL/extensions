import bpy
import os
import tempfile
from ..constants import get_addon_preferences
from PrismUtils.ProjectEntities import ProjectEntities
import PrismInit as prism

from ..msc.TX_List import refresh_image_list
from ..msc.util import getCurrentEntity

def createImage(context):
    before = set(bpy.data.images)
    preferences = get_addon_preferences(context)
    bpy.ops.image.new(
        name="Diffuse",
        width= int(preferences.Resolution),
        height=int(preferences.Resolution),
        alpha=True,
        generated_type='UV_GRID'
    )

    print("Creating new image with resolution:", preferences.Resolution)

    after = set(bpy.data.images)
    new_images = after - before

    if new_images:
        image = new_images.pop()
    else:
        image = None
    
    return image

def sendToPrism(path):
        
        p = ProjectEntities(prism.pcore)

        Entity = getCurrentEntity()
        
        p.ingestScenefiles(
            department = bpy.context.scene.prism_properties.Departments,
            task = bpy.context.scene.prism_properties.Tasks,
            entity = Entity,
            files = [path]
        )

def saveImageToTemp(image, delete):
    """
    Saves a Blender image to a temporary file and returns the file path.
    The image is saved in PNG format.
    
    Args:
        image (bpy.types.Image): The Blender image to save.
    
    Returns:
        str: The full path to the saved temporary image file.
    """
    if not image:
        raise ValueError("No image provided")

    temp_dir = tempfile.gettempdir()

    filename = image.name
    if not filename.lower().endswith(".png"):
        filename += ".png"

    filename = "".join(c for c in filename if c.isalnum() or c in (' ', '.', '_', '-')).rstrip()

    temp_path = os.path.join(temp_dir, filename)

    # Save the image
    image.filepath_raw = temp_path
    image.file_format = 'PNG'
    image.save()

    if delete:
        bpy.data.images.remove(image)

    return temp_path

class IMAGE_OT_image_to_prism(bpy.types.Operator):
    bl_idname = "prismtools.addimg"
    bl_label = "add images"
    bl_options = {'REGISTER','UNDO'}

    
    def execute(self,context):
        image = createImage(context)
        path = saveImageToTemp(image, delete=True)
        sendToPrism(path)
        refresh_image_list(self,context)
        return {'FINISHED'}
