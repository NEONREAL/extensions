import bpy
from bpy.props import EnumProperty, BoolProperty

class Quick_VAT_Preferences(bpy.types.AddonPreferences):
    bl_idname = __package__

    uv_index: EnumProperty(
        name="VAT UV Index",
        description="Which UV channel contains the VAT data",
        items=[
            ('0', "UV0", ""),
            ('1', "UV1", ""),
            ('2', "UV2", ""),
            ('3', "UV3", ""),
            ('4', "UV4", ""),
            ('5', "UV5", ""),
            ('6', "UV6", ""),
            ('7', "UV7", ""),
        ],
        default='1'
    )


    force_uv_index: BoolProperty(
        name="Force UV Index for VAT UV",
        default = True,
    )

    def draw(self, context):
        layout = self.layout
        box = layout.box()
        box.prop(self, "force_uv_index")
        if self.force_uv_index:
            uv_index_row = box.column()
            uv_index_row.label(text = "UV index:")
            uv_index_row.prop(self, "uv_index", expand = True)

