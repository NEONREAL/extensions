import bpy
import math
from ..constants import get_preferences

def get_nextPow2(x: int) -> int:
	# bitwise magic shit
	return 1 << (x - 1).bit_length()

def generate_uvset(obj: bpy.types.Object, uvname: str, width: int, height: int, frames: int):
	obj = obj
	mesh = obj.data

	preferences = get_preferences()
	force_uv_index = preferences.force_uv_index
	index = int(preferences.uv_index)


	if force_uv_index:
		# making sure that uvname isnt taken
		if uvname in mesh.uv_layers:
			mesh.uv_layers[uvname].name = f"{uvname}_old"

		# pad UVs if needed
		existing_uvs = len(mesh.uv_layers)
		if existing_uvs <= index:
			for _ in range((index - existing_uvs) + 1):
				new_layer = mesh.uv_layers.new()
				new_layer.name = "empty"
		
		# create new UV layer
		mesh.uv_layers[index].name = uvname
		uv_layer = mesh.uv_layers[index]


	else:
		if uvname in mesh.uv_layers:
			mesh.uv_layers.remove(mesh.uv_layers[uvname])

		uv_layer = mesh.uv_layers.new(name=uvname)

	for poly in mesh.polygons:
		for loop_index in range(poly.loop_start, poly.loop_start + poly.loop_total):
			vert_index = mesh.loops[loop_index].vertex_index

			# Column and row of vertex in texture (first frame only)
			col = vert_index % width
			row = (vert_index // width) * frames  # row index for the first frame)

			# Normalized UV coordinates: sample the **center of the pixel**
			u = (col + 0.5) / width
			v = (row + 0.5) / height  # height = total rows of the texture

			uv_layer.data[loop_index].uv = (u, v)

def calculate_dimensions(verts, frames) -> int:
	total_pixels = frames * verts

	side = int(math.sqrt(total_pixels))
	width = get_nextPow2(side)
	rows = math.ceil(verts / width)
	height = get_nextPow2(rows * frames)

	return width, height

def create_image(name: str, x: int, y: int):
	counter:int = 0

	for image in bpy.data.images:
		if image.name.startswith(name):
			counter = counter +1

	if name in bpy.data.images:
		name += f".{counter:03d}"

	bpy.ops.image.new(name=name, width=x, height=y, alpha=False, float= True)
	image = bpy.data.images[name]
	image.colorspace_settings.name = 'Non-Color'
	return image

def ensure_local_duplicate(obj):
	if not obj.override_library:
		return obj, False
	
	obj_local = obj.copy()
	obj_local.name = f"{obj.name}_local"
	obj_local.make_local()
	obj_local.data.make_local()
	bpy.context.collection.objects.link(obj_local)
	return obj_local, True