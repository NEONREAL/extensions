from .vat_logic import ensure_local_duplicate
import bpy


class DummyOperator(bpy.types.Operator):
    bl_idname = "object.dummy"
    bl_label = "dummy"

    def execute(self, context):
        obj = context.active_object
        ensure_local_duplicate(obj)
        return {"FINISHED"}

