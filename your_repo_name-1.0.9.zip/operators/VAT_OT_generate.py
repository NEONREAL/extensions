import bpy  # type: ignore
from ..constants import get_operator
import time
from .vat_logic import generate_vat

class VAT_OT_generate(bpy.types.Operator):
    bl_idname = get_operator("operator")
    bl_description = "Renames selected Object to Hello World"
    bl_label = "Renames selected object to Hello World"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        return context.active_object is not None and context.active_object.type == 'MESH'

    def execute(self, context):
        obj = context.active_object
        frames = 500
        image_name = "FairySitting"
        generate_vat(obj, frames, image_name)
        return {"FINISHED"}



    