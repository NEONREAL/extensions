import bpy
import time
import numpy as np
import math
from mathutils import Matrix

def get_mesh_data_for_frame(obj, frame: int):
	bpy.context.scene.frame_set(frame)
	depsgraph = bpy.context.evaluated_depsgraph_get()

	obj_eval = obj.evaluated_get(depsgraph)
	mesh = obj_eval.to_mesh()

	mat_world = obj.matrix_world
	world_verts = [mat_world @ v.co for v in mesh.vertices]

	obj_eval.to_mesh_clear()

	return np.array(world_verts, dtype=np.float32)

def get_nextPow2(x: int) -> int:
	return 1 << (x - 1).bit_length()

def generate_uvset(obj: bpy.types.Object, uvname: str, width: int, height: int, frames: int):
	mesh = obj.data

	# Remove existing UV map with same name
	if uvname in mesh.uv_layers:
		mesh.uv_layers.remove(mesh.uv_layers[uvname])

	uv_layer = mesh.uv_layers.new(name=uvname)

	for poly in mesh.polygons:
		for loop_index in range(poly.loop_start, poly.loop_start + poly.loop_total):
			vert_index = mesh.loops[loop_index].vertex_index

			# Column and row of vertex in texture (first frame only)
			col = vert_index % width
			row = (vert_index // width) * frames  # row index for the first frame)

			# Normalized UV coordinates: sample the **center of the pixel**
			u = (col + 0.5) / width
			v = (row + 0.5) / height  # height = total rows of the texture

			uv_layer.data[loop_index].uv = (u, v)

def calculate_dimensions(verts, frames) -> int:
	total_pixels = frames * verts

	side = int(math.sqrt(total_pixels))
	width = get_nextPow2(side)
	rows = math.ceil(verts / width)
	height = get_nextPow2(rows * frames)

	return width, height

def print_to_image(obj: bpy.types.Object, image , num_frames: int):
	width, height = image.size
	positions = np.zeros((height, width, 4), dtype=np.float32)
	positions[:, :, 3] = 1.0  # alpha channel

	depsgraph = bpy.context.evaluated_depsgraph_get()

	for f in range(num_frames):
		print(f)
		bpy.context.scene.frame_set(f)
		obj_eval = obj.evaluated_get(depsgraph)
		mesh = obj_eval.to_mesh()
		mat_world = obj.matrix_world
		world_coords = np.array([mat_world @ v.co for v in mesh.vertices], dtype=np.float32)
		obj_eval.to_mesh_clear()

		# Clip & normalize
		np.clip(world_coords, -1, 1, out=world_coords)
		world_coords = (world_coords + 1.0) / 2.0

		# Map each vertex to its proper pixel
		for vertex_index, co in enumerate(world_coords):
			x = vertex_index % width
			y = ((vertex_index // width)*num_frames) + f
			positions[y, x, 0:3] = co

	image.pixels.foreach_set(positions.ravel())
	image.update()

def print_to_image_fast(obj, image, num_frames):
	width, height = image.size
	vertices = len(obj.data.vertices)
	positions = np.zeros((height, width, 4), dtype=np.float32)
	positions[:, :, 3] = 1.0  # alpha

	depsgraph = bpy.context.evaluated_depsgraph_get()

	vertex_indices = np.arange(vertices)
	cols = vertex_indices % width
	row_base = (vertex_indices // width) * num_frames

	for f in range(num_frames):
		print(f"frame: {f}")
		bpy.context.scene.frame_set(f)
		obj_eval = obj.evaluated_get(depsgraph)
		mesh = obj_eval.to_mesh()
		mat_world = obj.matrix_world

		# Vectorized world coordinates
		world_coords = np.array([mat_world @ v.co for v in mesh.vertices], dtype=np.float32)
		obj_eval.to_mesh_clear()

		# Clip & normalize
		world_coords = np.clip((world_coords + 1) / 2, 0, 1)

		rows = row_base + f
		positions[rows, cols, 0:3] = world_coords

	image.pixels.foreach_set(positions.ravel())
	image.update()

def create_image(name: str, x: int, y: int):
	counter:int = 0
	for image in bpy.data.images:
		if image.name.startswith(name):
			counter = counter +1
	if name in bpy.data.images:
		name += f".{counter:03d}"
	bpy.ops.image.new(name=name, width=x, height=y, alpha=False, float= True)
	image = bpy.data.images[name]
	 		
	image.colorspace_settings.name = 'Non-Color'
	print(image.size)
	return image

def print_to_image_contig(obj: bpy.types.Object, image, num_frames: int):
    width, height = image.size
    vertices = len(obj.data.vertices)
    
    # Flattened 1D array for contiguous memory writes
    positions = np.zeros((height * width, 4), dtype=np.float32)
    positions[:, 3] = 1.0  # alpha channel
    
    depsgraph = bpy.context.evaluated_depsgraph_get()
    
    # Precompute column & base row indices
    vertex_indices = np.arange(vertices, dtype=np.int32)
    cols = vertex_indices % width
    row_base = (vertex_indices // width) * num_frames
    linear_base = row_base * width + cols  # 1D base index

    for f in range(num_frames):
        print(f"frame: {f}")
        bpy.context.scene.frame_set(f)
        obj_eval = obj.evaluated_get(depsgraph)
        mesh = obj_eval.to_mesh()
        mat_world = obj.matrix_world

        # Vectorized world coords
        world_coords = np.array([mat_world @ v.co for v in mesh.vertices], dtype=np.float32)
        obj_eval.to_mesh_clear()

        # Clip & normalize
        world_coords = np.clip((world_coords + 1) / 2, 0, 1)

        # Compute linear indices for this frame
        linear_indices = linear_base + f * width

        # Assign X, Y, Z
        positions[linear_indices, 0:3] = world_coords

    # Write all at once
    image.pixels.foreach_set(positions.ravel())
    image.update()

def generate_vat(obj: bpy.types.Object, frames: int, image_name: str = "TestVAT") -> None:
	start = time.time()
	#---------------
	vertices = len(obj.data.vertices)
	x, y = calculate_dimensions(vertices, frames)
	generate_uvset(obj=obj, uvname="VAT_UV", width=x, height=y, frames=frames)
	image = create_image(image_name, x, y)
	print_to_image_fast(obj, image, frames)
	#---------------
	end = time.time()
	duration= end - start
	print(f"finished in: {duration:.3f} seconds")
	print(f"average time per frame: {duration / frames:.5f} seconds")