import bpy  # type: ignore
import bmesh  # type: ignore
from ..constants import AddonProperties
from ..constants import get_operator, get_progress, get_preferences
import sys

class QUICK_VAT_Panel(bpy.types.Panel):
    bl_label = "Quick VAT"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = AddonProperties.panel_category

    def draw(self, context):
        props = context.scene.quick_vat

        layout = self.layout
        box = layout.box()
        #box.operator("object.dummy")
        box.label(text="Quick VAT Baker")

        # frame column
        frame_col = box.column(align = True)
        frame_col.prop(props, "start_frame", text = "Start Frame")
        frame_col.prop(props, "end_frame", text = "End Frame")
        box.separator(type = 'LINE')

        # export stuff
        box.prop(props, "export_mesh", text = " Export Mesh")
        box.prop(props, "export_texture", text = " Export Texture")
        box.prop(props, "export_json", text = " Export VAT Info")
        box.separator(type = 'LINE')
        
        

        # UV Stuff
        box.prop(props, "force_uv_index", toggle = True)
        if props.force_uv_index:
            box.prop(props, "uv_index", expand = True)
        
               # Data Layout
        row = box.row()
        row.prop(props, "LayoutMode", expand = True)
        if props.LayoutMode == "SingleLine":
            single_line = True
        else:
            single_line = False
        
        column = box.column(align = True)
        column.label(text = "Export Mode:")
        row = column.row()
        row.prop(props, "mode", text = "Mode", expand = True)

 

        if props.mode == 'Manual':
            export_col = box.column(align = True)
            export_col.label(text = "Export location:")
            export_col.prop(props, "export_location", text = "")
            export_col.label(text = "Name:")
            export_col.prop(props, "name", text = "")

        if props.mode == 'Conduit':
            conduit_installed = self.check_for_conduit_addon(context)
            if not conduit_installed:
                box.label(text = "Conduit addon not found. Please install Conduit to use this mode.")
                return
            conduit_active = self.check_for_conduit_activity()
            
            if not conduit_active:
                box = box.box()
                col = box.column()
                col.label(text = "Conduit is not active.", icon = "KEYTYPE_EXTREME_VEC")
                col.label(text = "Please start Conduit to use this mode.")
                return
            task_info = self.get_task_info()
            if not task_info:
                return
            
            asset = task_info.get("asset_name", "Unknown")
            if not asset:
                box.label(text="Not a Conduit File", icon = "KEYTYPE_EXTREME_VEC")
                return
            
            task = task_info.get("task_name", "Unknown")
            if not task:
                box.label(text="no task found", icon = "KEYTYPE_EXTREME_VEC")
                return
            box.label(text = f"Connected to Conduit Successfully", icon = "NODE_SOCKET_SHADER")
            box.label(text = f"Exporting to: {asset} / {task}")
        



        # VAT 
        vat_row = box.column()
        vat_row.scale_y = 2
        if props.mode == 'Manual':
            export = vat_row.operator(get_operator("generate_vat"), text = "Bake VAT")
            export.name = props.name
            export.path = props.export_location
            export.single_line = single_line
        elif props.mode == 'Conduit':
            export = vat_row.operator(get_operator("generate_vat"), text = "Bake VAT")
            export.name = task
            export.path = task_info["unity_path"]
            export.single_line = single_line

        active, frame = get_progress()
        start_frame = props.start_frame
        end_frame = props.end_frame

        total_range = end_frame - start_frame
        
        if total_range == 0:
            progress = 0
        else: 
            progress = min(max((frame) / total_range, 0.0), 1.0)


        if active:
            box.progress(factor = progress, text = f"{progress*100:.2f}%")
            box.label(text = f"frame: {frame + start_frame}")


    def check_for_conduit_addon(self, context) -> tuple[bool, str]:
        """Check if Conduit addon is installed."""
        if "bl_ext.neonreal_github_io.conduit_for_blender" in bpy.context.preferences.addons:
            return True, "bl_ext.neonreal_github_io.conduit_for_blender"
        if "bl_ext.vscode_development.conduit_for_blender" in bpy.context.preferences.addons:
            return True, "bl_ext.vscode_development.conduit_for_blender"
        return False, ""
    
    def get_task_info(self):
        _, conduit_name = self.check_for_conduit_addon(bpy.context)
        conduit_module = sys.modules.get(conduit_name)
        if not conduit_module:
            return None
        try:
            task_info = conduit_module.pipeline.get_task_info()
            print(task_info)
            return task_info
        except Exception as e:
            print(e)
            return None


    def check_for_conduit_activity(self):
        _, conduit_name = self.check_for_conduit_addon(bpy.context)
        conduit_module = sys.modules.get(conduit_name)
        if not conduit_module:
            return None
        heartbeat = conduit_module.ConduitClient.get_heartbeat()
        print(heartbeat)
        return heartbeat