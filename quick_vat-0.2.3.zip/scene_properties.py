import bpy                                              # type: ignore

class QuickVatProps(bpy.types.PropertyGroup):
    start_frame: bpy.props.IntProperty(default=0)       # type: ignore
    end_frame: bpy.props.IntProperty(default=100)       # type: ignore
    export_location: bpy.props.StringProperty(subtype = 'DIR_PATH')# type: ignore
    export_mesh: bpy.props.BoolProperty()               # type: ignore
    export_texture: bpy.props.BoolProperty()            # type: ignore
    export_json: bpy.props.BoolProperty()               # type: ignore
    name: bpy.props.StringProperty(default = "test")    # type: ignore
    mode: bpy.props.EnumProperty(
        items = [
            ('Manual', "Manual", ""),
            ('Conduit', "Conduit", "")
        ],
        default = 'Manual'
    )# type: ignore

    uv_index: bpy.props.EnumProperty(
        name="VAT UV Index",
        description="Which UV channel contains the VAT data",
        items=[
            ('0', "UV0", ""),
            ('1', "UV1", ""),
            ('2', "UV2", ""),
            ('3', "UV3", ""),
            ('4', "UV4", ""),
            ('5', "UV5", ""),
            ('6', "UV6", ""),
            ('7', "UV7", ""),
        ],
        default='1'
    )# type: ignore

    force_uv_index: bpy.props.BoolProperty(
        name="Force UV Index for VAT UV",
        default = True,
    )# type: ignore

    LayoutMode: bpy.props.EnumProperty(
        name="LayoutMode",
        description="Wich way to Layout the VAT Data",
        items = [
            ("Power2", "Force Power of 2", "Exported Textures will always result in power of 2 dimensions"),
            ("SingleLine", "Single Line", "Exported Texture will be vertices x frames")
        ]
    ) # type: ignore


