import bpy

class Quick_VAT_Preferences(bpy.types.AddonPreferences):
    bl_idname = __package__



    def draw(self, context):
        layout = self.layout
        box = layout.box()

