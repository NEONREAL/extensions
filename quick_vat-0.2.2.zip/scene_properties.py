import bpy

class QuickVatProps(bpy.types.PropertyGroup):
    start_frame: bpy.props.IntProperty(default=0)
    end_frame: bpy.props.IntProperty(default=100)
    export_location: bpy.props.StringProperty(subtype = 'DIR_PATH')
    export_mesh: bpy.props.BoolProperty()
    export_texture: bpy.props.BoolProperty()
    export_json: bpy.props.BoolProperty()
    name: bpy.props.StringProperty(default = "test")
    mode: bpy.props.EnumProperty(
        items = [
            ('Manual', "Manual", ""),
            ('Conduit', "Conduit", "")
        ],
        default = 'Manual'
    )


    uv_index: bpy.props.EnumProperty(
        name="VAT UV Index",
        description="Which UV channel contains the VAT data",
        items=[
            ('0', "UV0", ""),
            ('1', "UV1", ""),
            ('2', "UV2", ""),
            ('3', "UV3", ""),
            ('4', "UV4", ""),
            ('5', "UV5", ""),
            ('6', "UV6", ""),
            ('7', "UV7", ""),
        ],
        default='1'
    )


    force_uv_index: bpy.props.BoolProperty(
        name="Force UV Index for VAT UV",
        default = True,
    )


