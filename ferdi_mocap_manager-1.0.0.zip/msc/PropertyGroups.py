import bpy #type: ignore


def toggle_recording_streams(self, context):
    if self.is_recording_active:

        # start XSense
        bpy.ops.wm.startstream()
        bpy.ops.wm.startrecord()


        # start FaceIT
        context.scene.faceit_live_source = 'EPIC'
        bpy.ops.faceit.receiver_start()
            
    else:
        # stopping XSense
        bpy.ops.wm.startrecord()
        bpy.ops.wm.startstream()

        # stopping FaceIT
        bpy.ops.faceit.receiver_stop()
        bpy.ops.faceit.import_live_mocap(animate_shapes = True,bake_to_control_rig = True,animate_head_rotation = False,animate_eye_rotation_shapes = True)#,mirror_x = True,)




def connect_xsense(self, context):
    pass

class StreamSettings(bpy.types.PropertyGroup):
    is_recording_active: bpy.props.BoolProperty(
        name="Record",
        description="Toggle XSense and FaceIT streams",
        default=False,
        update=toggle_recording_streams # This triggers the function above
    )# type: ignore

    xsense_connected: bpy.props.BoolProperty(
        name="Record",
        description="Toggle XSense and FaceIT streams",
        default=False,
        update=toggle_recording_streams # This triggers the function above
    )# type: ignore


    faceit_connected: bpy.props.BoolProperty(
        name="Record",
        description="Toggle XSense and FaceIT streams",
        default=False,
        update=toggle_recording_streams # This triggers the function above
    )# type: ignore

    server_ip: bpy.props.StringProperty(
    )# type: ignore

