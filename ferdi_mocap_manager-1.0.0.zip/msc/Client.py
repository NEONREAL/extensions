import socket
import threading
import queue
import bpy #type: ignore


class Client:
    def __init__(self, host, port=5000, timeout=3.0):
        self.host = host
        self.port = port
        self.timeout = timeout
        self.socket = None
        self.is_connected = False
        self._connection_thread = None
        self.msg_queue = queue.Queue()

    def connect(self, callback=None):
        """
        Spawns a background thread to connect so the UI doesn't freeze.
        callback: Optional function to run after connection attempt (success: bool)
        """
        if self.is_connected:
            return True

        # Start the connection attempt in a separate thread
        self._connection_thread = threading.Thread(
            target=self._run_connect, 
            args=(callback,), 
            daemon=True
        )
        self._connection_thread.start()
        return True # Returns immediately to keep UI alive

    def _run_connect(self, callback):
        """The actual connection logic running in the background."""
        try:
            # Create a fresh socket for every connection attempt
            self.socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            self.socket.settimeout(self.timeout)
            
            self.socket.connect((self.host, self.port))
            
            # Switch to blocking mode for the data loop
            self.socket.settimeout(None)
            
            self.is_connected = True
            print(f"Successfully connected to {self.host}")

            # Start receiving data
            threading.Thread(target=self.receive_loop, daemon=True).start()
            
            if callback: callback(True)

        except (socket.timeout, ConnectionRefusedError, Exception) as e:
            print(f"Connection failed: {e}")
            self.is_connected = False
            if self.socket:
                self.socket.close()
            if callback: callback(False)

    def receive_loop(self):
            """Handles incoming data."""
            while self.is_connected:
                try:
                    data = self.socket.recv(1024) #type: ignore
                    if not data:
                        print("Server closed connection.")
                        break
                    
                    # Decode the message to a string
                    message = data.decode().strip()
                    print(f"Server sent: {message}")

                    # ONLY put the string command in the queue
                    if message == "TEST":
                        print("adding to queue:", message)
                        self.msg_queue.put(message)

                    if message == "RECORD_START":
                        self.msg_queue.put(message)
                        print("adding to queue:", message)

                    if message == "RECORD_STOP":
                        print("adding to queue:", message)
                        self.msg_queue.put(message)

                    
                        
                except Exception as e:
                    print(f"Receive error: {e}")
                    break
            
            self.disconnect()
        

    def disconnect(self):
        self.is_connected = False
        if self.socket:
            try:
                self.socket.shutdown(socket.SHUT_RDWR)
                self.socket.close()
            except:
                pass
        print("Disconnected.")


    def StartRecording(self):
        pass
