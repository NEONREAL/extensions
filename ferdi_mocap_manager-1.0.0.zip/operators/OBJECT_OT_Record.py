import bpy  # type: ignore
from ..constants import get_operator


# Define the operator to snap FK bones to IK bones
class OBJECT_OT_Record(bpy.types.Operator):
    bl_idname = get_operator("record")
    bl_description = "Renames selected Object to Hello World"
    bl_label = "Record"
    bl_options = {"REGISTER", "UNDO"}


    enable: bpy.props.BoolProperty()#type: ignore

    def execute(self, context):
        
        settings = context.scene.stream_settings
        settings.is_recording_active = self.enable
        print(self.enable)
        return {'FINISHED'}