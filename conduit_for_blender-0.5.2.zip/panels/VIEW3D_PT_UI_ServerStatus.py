import bpy  # type: ignore
from ..constants import AddonProperties, get_operator
from ..BlenderServer import get_server
from ..ConduitClient import get_heartbeat
from ..pipeline import is_registered


class VIEW3D_PT_UI_ServerStatus(bpy.types.Panel):
    bl_label = "Server Status"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = AddonProperties.panel_category

    def draw(self, context):
        layout = self.layout

        if bpy.app.version[0] > 4:
            ok = "NODE_SOCKET_SHADER"
            failure = "KEYTYPE_EXTREME_VEC"
        else:
            ok = "KEYTYPE_JITTER_VEC"
            failure = "KEYTYPE_EXTREME_VEC"


        hb = get_heartbeat()
        hb_box = layout.box()
        if hb:
            hb_box.label(text="Conduit: Connected", icon=ok)
        else:
            hb_box.label(text="Conduit: Offline", icon=failure)

        # show current connector status
        server_box = layout.box()
        server = get_server()



        if server._running:
            server_box.label(text="Blender: Running", icon=ok)
        else:
            server_box.label(text="Blender: Offline", icon=failure)

        if not is_registered(bpy.app.binary_path):
            reg_box = layout.box()
            reg_box.scale_y = 2
            reg_box.operator(get_operator("register_blender"), text="Register Blender Version", icon="ADD")
        else:
            reg_box = layout.box()
            reg_box.label(text="Blender Version Registered", icon=ok)
