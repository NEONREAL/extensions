import bpy  # type: ignore
from ..constants import get_operator
from ..ConduitClient import register
from ..pipeline import get_settings, is_registered
from pathlib import Path
import json
import sys
import os

class PIPELINE_OT_RegisterBlender(bpy.types.Operator):
    bl_idname = get_operator("register_blender")
    bl_description = "Registers Blender as Executable for Conduit"
    bl_label = ""
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):

        data, json_path = get_settings()
        path = bpy.app.binary_path
        version = bpy.app.version_string
        existing_blender_versions_dict = data.get("blender_versions", [])

        if not is_registered(path):
            self.report({'INFO'}, f"Blender Version is already registered as {version} at path {path}")


        existing_blender_versions_dict[version] = path
        data["blender_versions"] = existing_blender_versions_dict
        with open(json_path, "w") as f:
            json.dump(data, f, indent=4)
        return {"FINISHED"}
