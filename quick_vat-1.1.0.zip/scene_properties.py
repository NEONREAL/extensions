import bpy

class QuickVatProps(bpy.types.PropertyGroup):
    start_frame: bpy.props.IntProperty(default=0)
    end_frame: bpy.props.IntProperty(default=100)
    export_location: bpy.props.StringProperty(subtype = 'DIR_PATH')
    export_mesh: bpy.props.BoolProperty()
    export_texture: bpy.props.BoolProperty()
    export_json: bpy.props.BoolProperty()
    name: bpy.props.StringProperty(default = "test")
    mode: bpy.props.EnumProperty(
        items = [
            ('Manual', "Manual", ""),
            ('Conduit', "Conduit", "")
        ],
        default = 'Manual'
    )


