import bpy
import numpy as np
import time
from ..constants import get_operator, add_frame, reset
from .vat_logic import calculate_dimensions, create_image, generate_uvset
import os
class VAT_OT_GenerateModal(bpy.types.Operator):
    bl_idname = get_operator("generate_vat")
    bl_label = "Generate VAT"
    bl_description = "Generates a Vertex Animation Texture"
    bl_options = {"REGISTER", "UNDO"}

    _timer = None

    name: bpy.props.StringProperty()
    path: bpy.props.StringProperty()


    @classmethod
    def poll(cls, context):
        return context.active_object is not None and context.active_object.type == 'MESH'

    def execute(self, context):
        self.start_frame = context.scene.quick_vat.start_frame
        self.frames = context.scene.quick_vat.end_frame - self.start_frame
        self.obj = context.active_object
        self.image_name = self.name
        self.start_time = time.time()

        self.vertices = len(self.obj.data.vertices)
        self.width, self.height = calculate_dimensions(self.vertices, self.frames)
        self.image = create_image(self.image_name, self.width, self.height)

        self.depsgraph = bpy.context.evaluated_depsgraph_get()
        self.vertex_indices = np.arange(self.vertices)
        self.cols = self.vertex_indices % self.width
        self.row_base = (self.vertex_indices // self.width) * self.frames
        self.positions = np.zeros((self.height, self.width, 4), dtype=np.float32)
        self.positions[:, :, 3] = 1.0

        self.frame = 0

        # Add a timer to ensure modal keeps running
        wm = context.window_manager
        self._timer = wm.event_timer_add(0.001, window=context.window)
        wm.modal_handler_add(self)

        return {'RUNNING_MODAL'}

    def modal(self, context, event):
        if event.type == 'ESC':
            self.finish(context)
            print("VAT generation canceled.")
            return {'CANCELLED'}

        # Only run on timer events
        if event.type == 'TIMER':
            add_frame()
            if self.frame < self.frames:
                bpy.context.scene.frame_set(self.frame + self.start_frame)
                obj_eval = self.obj.evaluated_get(self.depsgraph)
                mesh = obj_eval.to_mesh()
                mat_world = self.obj.matrix_world

                world_coords = np.array([mat_world @ v.co for v in mesh.vertices], dtype=np.float32)
                obj_eval.to_mesh_clear()

                world_coords = np.clip((world_coords + 1) / 2, 0, 1)
                rows = self.row_base + self.frame
                self.positions[rows, self.cols, 0:3] = world_coords

                self.frame += 1
                return {'RUNNING_MODAL'}

            # Finished all frames
            self.image.pixels.foreach_set(self.positions.ravel())
            self.image.update()
            duration = time.time() - self.start_time
            print(f"VAT finished in {duration:.3f}s ({duration/self.frames:.4f}s per frame, {self.frames} total frames)")
            reset()
            self.finish(context)
            return {'FINISHED'}

        return {'PASS_THROUGH'}

    def finish(self, context):
        """Cleanup when operator ends or is canceled."""
        wm = context.window_manager
        if self._timer is not None:
            wm.event_timer_remove(self._timer)
        self._timer = None

        generate_uvset(self.obj, "VAT_UV", self.width, self.height, self.frames)
        # exporting stuff:
        if context.scene.quick_vat.export_mesh:
            self.export_mesh(context)
        if context.scene.quick_vat.export_texture:
            self.export_texture(context)
        if context.scene.quick_vat.export_json:
            self.export_json(context)

    def export_json(self, context):
        import json
        name = self.name
        formatted_name = f"VAT_{name}.vatinfo"
        path = self.path
        export_path = os.path.join(path, formatted_name)

        data = {
            "name": name.lower().capitalize(),
            "width": self.width,
            "height": self.height,
            "frames": self.frames,
            "vertices": self.vertices,
            "generated": False
        }

        with open(export_path, 'w') as f:
            json.dump(data, f, indent=4)
        return

    def export_mesh(self, context):
        name = context.scene.quick_vat.name
        formatted_name = f"SM_{name}.fbx"
        path = context.scene.quick_vat.export_location
        export_path = os.path.join(path, formatted_name)
        bpy.ops.export_scene.fbx(
            filepath = export_path,
            bake_anim=False,
            use_selection = True
            )
        return
    
    def export_texture(self, context):
        name = context.scene.quick_vat.name
        formatted_name = f"T_{name}_VAT.png"
        path = context.scene.quick_vat.export_location
        export_path = os.path.join(path, formatted_name)

        self.image.filepath_raw = export_path
        self.image.file_format = 'PNG'
        self.image.save()

