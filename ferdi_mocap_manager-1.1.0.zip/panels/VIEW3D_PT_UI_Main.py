import bpy  # type: ignore
from ..constants import AddonProperties
from ..operators.SERVER_OT_Connect import SERVER_OT_Connect
import addon_utils #type: ignore

class VIEW3D_PT_UI_Sample(bpy.types.Panel):
    bl_label = "Mocap Manager"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = AddonProperties.panel_category

    def draw(self, context):
        layout = self.layout
        settings = context.scene.stream_settings
        box = layout.box()
        box.scale_y = 0.75

        self.check_addons(box)

        # Change the text dynamically based on the state
        button_text = "Stop Recording" if settings.is_recording_active else "Start Recording"
        button_icon = 'PAUSE' if settings.is_recording_active else 'RECORD_ON'



        row = layout.row()
        row.scale_y = 1.5
        row.prop(settings, "is_recording_active", text=button_text, icon=button_icon, toggle=True)

        col = layout.column()
        col.prop(settings, "server_ip", text="Server IP")
        col.operator(SERVER_OT_Connect.bl_idname, text = "Connect")


        
    def check_addons(self, parent):
        # icons
        success_icon = 'NODE_SOCKET_SHADER'
        failure_icon = 'ERROR'

        # Addon detection
        FaceIT_id = 'bl_ext.extensions.faceit'
        Mvn_id = 'MVNBlenderPlugin-main'
        _, FaceIT = addon_utils.check(FaceIT_id)
        _, Mvn = addon_utils.check(Mvn_id)

        # Face it
        if FaceIT:
            parent.label(text="FaceIT", icon =success_icon)
        else:
            parent.alert = True
            parent.label(text="FaceIT", icon =failure_icon)
            parent.alert = False

        # MVN
        if Mvn:
            parent.label(text="Mvn", icon =success_icon)
        else:
            parent.alert = True
            parent.label(text="Mvn", icon =failure_icon)
            parent.alert = False

        return Mvn and FaceIT




        


        