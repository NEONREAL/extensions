from .Client import Client

class ClientManager:
    _instance = None

    def __new__(cls, *args, **kwargs):
        if cls._instance is None:
            cls._instance = super(ClientManager, cls).__new__(cls)
            cls._instance._initialized = False
        return cls._instance

    def __init__(self, ip=None):
        if self._initialized:
            return
            
        self.ip = ip
        self.client = None
        self._initialized = True

    def connect(self):
        """Initializes the client connection if it hasn't been already."""
        if not self.ip:
            print("Error: No IP address provided for connection.")
            return
            
        if self.client is None:
            print(f"Connecting to client at {self.ip}...")
            self.client = Client(self.ip)
            return self.client.connect()
        else:
            self.client.connect()