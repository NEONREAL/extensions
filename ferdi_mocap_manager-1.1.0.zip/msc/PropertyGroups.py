import bpy #type: ignore


def toggle_recording_streams(self, context):
    if self.is_recording_active:

        # start XSense
        bpy.ops.wm.startstream()
        bpy.ops.wm.startrecord()


        # start FaceIT
        context.scene.faceit_live_source = 'EPIC'
        bpy.ops.faceit.receiver_start()
            
    else:
        # stopping XSense
        bpy.ops.wm.startrecord()
        bpy.ops.wm.startstream()

        # stopping FaceIT
        bpy.ops.faceit.receiver_stop()
        try:
            bpy.ops.faceit.import_live_mocap(
                use_smooth_face_filter=False, 
                smooth_regions=
                    {"name":"", 
                    "eyes":True, 
                    "eyelids":True, 
                    "brows":True, 
                    "cheeks":True, 
                    "nose":True, 
                    "mouth":True, 
                    "tongue":True, 
                    "other":True}, 
                smoothing_filter_face='SMA', 
                smooth_window_face=3, 
                smooth_head=False, 
                smoothing_filter_head='SMA', 
                smooth_window_head=3, 
                smooth_eye_look_animation=False, 
                smoothing_filter_eye_bones='SMA',
                smooth_window_eye_bones=3, 
                eyes=True, 
                eyelids=True, 
                brows=True, 
                cheeks=True, 
                nose=True, 
                mouth=True, 
                tongue=True, 
                other=True, 
                new_action_name= "placeholder",# context.scene.stream_settings.take_name, 
                new_action_exists=False, 
                overwrite_method='REPLACE', 
                bake_to_control_rig=True, 
                frame_start=0, 
                use_region_filter=False, 
                set_scene_frame_range=True, 
                audio_filename="", 
                load_audio_file=False, 
                remove_audio_tracks_with_same_name=True, 
                animate_head_rotation=True, 
                animate_head_location=False, 
                animate_shapes=True, 
                animate_eye_rotation_shapes=True, 
                animate_eye_rotation_bones=True, 
                attempt_to_skip_shape_keys_on_eye_objects=True, 
                can_bake_control_rig=True, 
                record_frame_rate=60, 
                frame_rate_presets='60')


        except Exception as e:
            print(e)


def connect_xsense(self, context):
    pass

class StreamSettings(bpy.types.PropertyGroup):
    is_recording_active: bpy.props.BoolProperty(
        name="Record",
        description="Toggle XSense and FaceIT streams",
        default=False,
        update=toggle_recording_streams # This triggers the function above
    )# type: ignore

    xsense_connected: bpy.props.BoolProperty(
        name="Record",
        description="Toggle XSense and FaceIT streams",
        default=False,
        update=toggle_recording_streams # This triggers the function above
    )# type: ignore


    faceit_connected: bpy.props.BoolProperty(
        name="Record",
        description="Toggle XSense and FaceIT streams",
        default=False,
        update=toggle_recording_streams # This triggers the function above
    )# type: ignore

    server_ip: bpy.props.StringProperty(
    )# type: ignore

    take_name: bpy.props.StringProperty()#type:ignore

