import bpy  # type: ignore
from ..constants import get_operator
# Import your ClientManager singleton here
# from .ClientManager import ClientManager 

class SERVER_OT_Connect(bpy.types.Operator):
    bl_idname = get_operator("connect")
    bl_label = "Connect to Server"
    bl_description = "Initializes the Mocap Client connection"

    def execute(self, context):
        settings = context.scene.stream_settings
        self.ip = settings["server_ip"]
        self.report({'INFO'}, f"Connecting to {self.ip}...")

        from ..msc.ClientManager import ClientManager
        manager = ClientManager(self.ip)

        try:
            success = manager.connect()
            if success:
                self.report({'INFO'}, f"Connected to {self.ip}")
            else:
                self.report({'WARNING'}, f"Could not connect to {self.ip}")
        except Exception as e:
            self.report({'ERROR'}, f"Failed to connect: {str(e)}")
            return {'CANCELLED'}

        bpy.ops.mocap_mgr.network_listener()
        return {"FINISHED"}