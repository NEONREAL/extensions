import bpy  # type: ignore
from ..constants import get_operator


# Define the operator to snap FK bones to IK bones
class OBJECT_OT_Record(bpy.types.Operator):
    bl_idname = get_operator("record")
    bl_description = "Renames selected Object to Hello World"
    bl_label = "Record"
    bl_options = {"REGISTER", "UNDO"}


    enable: bpy.props.BoolProperty()#type: ignore
    name: bpy.props.StringProperty()#type: ignore

    def execute(self, context):
        
        settings = context.scene.stream_settings
        
        if self.enable:
            settings.take_name = self.name
            print(f"setting {settings.take_name} to {self.name}")
            new_action = bpy.data.actions.new(self.name)
            new_action.slots.new(id_type='ARMATURE', name="test")

            FaceRigObj = context.scene.faceit_control_armature

            if not FaceRigObj.animation_data:
                FaceRigObj.animation_data_create()

            FaceRigObj.animation_data.action = new_action


        settings.is_recording_active = self.enable
        return {'FINISHED'}

