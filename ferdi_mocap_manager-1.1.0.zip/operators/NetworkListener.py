import bpy #type: ignore
from ..constants import get_operator
class WM_OT_NetworkCommandListener(bpy.types.Operator):
    bl_idname = get_operator("network_listener")
    bl_label = "Network Listener"
    
    _timer = None

    def modal(self, context, event):
        if event.type == 'TIMER':
            from ..msc.ClientManager import ClientManager
            manager = ClientManager()
            
            # Check if there are any messages waiting in the queue
            if manager.client and not manager.client.msg_queue.empty():
                dict = manager.client.msg_queue.get()
                command = dict.get("cmd")
                data = dict.get("data")

                
                print(f"Executing Network Command: {command}")
                
                if command == "debug_string":
                    print(data)
                    bpy.ops.mocap_mgr.dummy()

                if command == "record_start":
                    print("starting record")
                    bpy.ops.mocap_mgr.record(enable=True, name=f"{data.get('take_name')}_{int(data.get('take_version')):03}")

                if command == "record_stop":
                    print("stopping record")
                    bpy.ops.mocap_mgr.record(enable=False)


        return {'PASS_THROUGH'}

    def execute(self, context):
        self._timer = context.window_manager.event_timer_add(0.1, window=context.window)
        context.window_manager.modal_handler_add(self)
        return {'RUNNING_MODAL'}