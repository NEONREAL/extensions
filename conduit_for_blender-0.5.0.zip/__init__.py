import bpy  # type: ignore
from . import BlenderServer

# Preferences
from .preferences import Conduit_Preferences

# Operators
from .operators.CONDUIT_OT_LinkCollection import CONDUIT_OT_LinkCollection
from .operators.CONDUIT_OT_SaveMasterVersion import CONDUIT_OT_SaveMasterVersion
from .operators.CONDUIT_OT_SaveNewVersion import CONDUIT_OT_SaveNewVersion
from .operators.PIPELINE_OT_RegisterBlender import PIPELINE_OT_RegisterBlender
from .operators.CONDUIT_OT_CreateTexture import CONDUIT_OT_CreateTexture
from .operators.CONDUIT_OT_ImportTexture import CONDUIT_OT_ImportTexture
from .operators.CONDUIT_OT_RefreshTasks import CONDUIT_OT_RefreshTasks

# Panels
from .panels.VIEW3D_PT_UI_AssetManager import VIEW3D_PT_UI_AssetManager
from .panels.VIEW3D_PT_UI_ServerStatus import VIEW3D_PT_UI_ServerStatus
from .panels.Shading_PT_TextureManager import Shading_PT_TextureManager


# PG
from .TextureManager.TextureManagerProps import CONDUIT_TexturePG
from .TextureManager.TextureManagerProps import TaskItem
from .TextureManager.TextureTaskList import UI_UL_list, TaskProperties, TaskListItem

# Module-level variable for the server instance
_server_instance: BlenderServer.BlenderServer | None = None


# Read addon manifest info
def load_manifest_info():
    from .constants import get_manifest

    manifest = get_manifest()

    extension_name = manifest["name"]
    version_tuple = tuple(int(x) for x in manifest["version"].split("."))
    blender_version_tuple = tuple(
        int(x) for x in manifest["blender_version_min"].split(".")
    )

    bl_info = {
        "name": extension_name,
        "version": version_tuple,
        "blender": blender_version_tuple,
    }
    return bl_info


blender_manifest = load_manifest_info()
bl_info = {
    "name": blender_manifest["name"],
    "description": "Adds RIG UI for Supported Rigs",
    "author": "Your Name",
    "version": blender_manifest["version"],
    "blender": blender_manifest["blender"],
    "location": "Npanel",
    "support": "COMMUNITY",
    "category": "UI",
}

# Classes to register
classes = [
    Conduit_Preferences,
    TaskItem,
    TaskListItem,
    TaskProperties,
    UI_UL_list,
    CONDUIT_TexturePG,

    CONDUIT_OT_LinkCollection,
    CONDUIT_OT_SaveMasterVersion,
    CONDUIT_OT_SaveNewVersion,
    CONDUIT_OT_CreateTexture,
    CONDUIT_OT_RefreshTasks,
    CONDUIT_OT_ImportTexture,

    PIPELINE_OT_RegisterBlender,

    VIEW3D_PT_UI_ServerStatus,
    VIEW3D_PT_UI_AssetManager,
    Shading_PT_TextureManager
]


def register():
    global _server_instance

    for cls in classes:
        bpy.utils.register_class(cls)


    # create Property Groups
    bpy.types.Scene.conduit_texture_properties = bpy.props.PointerProperty(type=CONDUIT_TexturePG)
    bpy.types.Scene.TaskProperties = bpy.props.PointerProperty(type=TaskProperties)

    # Create and start the server
    _server_instance = BlenderServer.BlenderServer()
    _server_instance.start(background=True)  # runs in background thread


def unregister():
    global _server_instance

    # Stop server if running
    if _server_instance:
        _server_instance.stop()
        _server_instance = None

    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)


if __name__ == "__main__":
    register()
