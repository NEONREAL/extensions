class dictionary:
    FK_arms = {
        "LeftArm": "UpperArm.L",
        "LeftForeArm": "LowerArm.L",
        "LeftHand": "Hand.L",
    }
